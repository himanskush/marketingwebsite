export default function Products() {
    
    return (
        <>
            <div>
                Product 1
            </div>
        </>
    )
}
