module.exports = {
    images: {
      domains: ['hostinger.in'],
    },
  }